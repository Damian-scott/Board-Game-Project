/**************************************
The Coding Baddies Project
By Damian & Arianna
4/25/2024
***************************************/

#include <iostream>
#include <string>

// To use transform which allows the computer to take case sensitivity
#include <algorithm> 

#include <cstdlib>
#include <ctime>

using namespace std;

//Function for Rock, Paper, & Scissors
void myFunction(string& player_1, string& player_2)
{
    string play_1, play_2;
    cout << "Player 1, enter your name: ";
    cin >> player_1;
    cout << "Hello " << player_1 << " , what do you want to play? Rock, paper or scissors: ";
    cin >> play_1;
    cout << "Player 2, enter your name: ";
    cin >> player_2;
    cout << "Hello " << player_2 << " , what do you want to play? Rock, paper or scissors: ";
    cin >> play_2;

    //Convert inputs to lowercase for case-insensitive comparison
    transform(play_1.begin(), play_1.end(), play_1.begin(), ::tolower);
    transform(play_2.begin(), play_2.end(), play_2.begin(), ::tolower);

    if ((play_1 == "rock" && play_2 == "scissors") || (play_1 == "paper" && play_2 == "rock") || (play_1 == "scissors" && play_2 == "paper"))
    {
     cout << "Congratulations, " << player_1 << " has won!!!" << endl;
    }
    else if ((play_2 == "rock" && play_1 == "scissors") || (play_2 == "paper" && play_1 == "rock") || (play_2 == "scissors" && play_1 == "paper"))
    {
    cout << "Congratulations, " << player_2 << " has won!!!" << endl;
    }
    else
    cout << "Whomp Whomp, it's a tie :(" << endl;
}

//Function for Number Guesser
void myFunction(int guess)
{
    // Seed for random number generator
    srand(time(0)); 
    
    // Generate random number between 1 and 100
    int secretNumber = rand() % 100 + 1; 
    int attempts = 0;

    cout << "Welcome to the Guessing Game!\n";
    cout << "I have chosen a number between 1 and 100. Try to guess it!\n";

    //Make a do nested loopto ensure that the user gets at least one chance to make a guess
    //and then it continues to guess until they guess the correct number
    do 
    {
    cout << "Enter your guess: ";
    cin >> guess;
    attempts++;

    if (guess < secretNumber) 
    {
    cout << "Too low! Try again.\n";
    } else if (guess > secretNumber) 
        {
        cout << "Too high! Try again.\n";
        } 
        else 
        {
        cout << "Congratulations! You guessed it right in " << attempts << " attempts!\n";
        }
    } 
    while (guess != secretNumber);
}

//Function for Scramble Game
void scrambleWord(string& word) 
{
  random_shuffle(word.begin(), word.end());
}

//Function to check if the guess is correct
bool isCorrect(const string& guess, const string& original) 
{
  return guess == original;
}

// Main game logic
void playUnscrambleGame() 
{
  // Array of words to be unscrambled
  string words[] = {"fizz", "college", "nickelodeon", "elephant", "environment"};
  
  //sizeof helps the code figure out how many words are in the words list. 
  const int numWords = sizeof(words) / sizeof(words[0]);

  // Seed the random number generator
  srand(time(0));

  // Pick a random word from the array
  int index = rand() % numWords;
  string originalWord = words[index];
  
  // Make a copy to scramble & scramble the words
  string scrambledWord = originalWord; 
  scrambleWord(scrambledWord);

  // Welcome message
  cout << "Welcome to the Unscramble Game!" << endl;
  cout << "Unscramble the following word: " << scrambledWord << endl;

  // User input loop
  string guess;
  do 
  {
    // Prompt for user input
   cout << "Enter your guess (or type 'quit' to exit): ";
   cin >> guess;

  // Check if the guess is correct
  if (guess == "quit") 
  {
    cout << "The correct word was: " << originalWord << endl;
    break;
  } 
  else if (isCorrect(guess, originalWord)) 
  {
    cout << "Congratulations! You guessed it right!" << endl;
    break;
  } 
  else 
  cout << "Incorrect guess. Try again!" << endl;     
} 
  while (true);
}

int main()
{
    //use this to make the menu of choices for the user to play
    int option;

    //Make user input which function to call
    cout << "What game would you like to play? 1. Rock, Paper, Scissors. 2. Number Guesser 3. Scramble \n";
    cin >> option;

    if (option == 1)
    {
        string p1_name, p2_name;

        //Call for Rock, Paper, Scissors game
        myFunction(p1_name, p2_name);
    }
    else if(option == 2)
    {
        int secretNumber;
        
        //Call for Number Guesser Game
        myFunction(secretNumber);

    }
    else if (option == 3)
    {
        // Call the Scramble game
        playUnscrambleGame();
        return 0;
    }
    return 0;
}